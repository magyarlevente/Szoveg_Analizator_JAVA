import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Analyzer
{
    public int numberOfWords;
    public int numberOfLetters;
    public int numberOfSentences;
    public String mostCommonWord;
    public List<String> palindromes;

    public Analyzer(int numberOfWords, int numberOfLetters, int numberOfSentences, String mostCommonWord, List<String> palindromes)
     {
        this.numberOfWords = numberOfWords;
        this.numberOfLetters = numberOfLetters;
        this.numberOfSentences = numberOfSentences;
        this.mostCommonWord = mostCommonWord;
        this.palindromes = palindromes;
    }

    public static Analyzer analyzeText(String text)
    {
        String[] words = text.split("\\s+");
        int wordCount = words.length;
        int letterCount = text.replaceAll("[^a-zA-Z]", "").length();
        int sentenceCount = text.split("[.!?]").length;
        Map<String, Integer> wordFrequency = new HashMap<>();
        Set<String> uniquePalindromes = new HashSet<>();

        for (String word : words)
        {
            String cleanedWord = word.replaceAll("[^a-zA-Z]", "").toLowerCase();
            if (cleanedWord.isEmpty() || cleanedWord.length() < 2)
            continue;

            wordFrequency.put(cleanedWord, wordFrequency.getOrDefault(cleanedWord, 0) + 1);

            if (isPalindrome(cleanedWord))
            {
                uniquePalindromes.add(cleanedWord);
            }
        }

        String mostCommonWord = wordFrequency.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("Nincs adat");

        return new Analyzer(wordCount, letterCount, sentenceCount, mostCommonWord, new ArrayList<>(uniquePalindromes));
    }

    private static boolean isPalindrome(String word)
    {
        String reversed = new StringBuilder(word).reverse().toString();
        return word.equals(reversed);
    }

    @Override
    public String toString()
    {
        return "Szavak száma: " + numberOfWords + "\n" +
                "Betűk száma: " + numberOfLetters + "\n" +
                "Mondatok száma: " + numberOfSentences + "\n" +
                "Leggyakoribb szó: " + mostCommonWord + "\n" +
                "Palindrom szavak: " + palindromes;
    }
}