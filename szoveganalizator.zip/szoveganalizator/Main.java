import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Adja meg a fájl nevét: ");
        String filename = scanner.nextLine();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename)))
        {
            String line;
            StringBuilder content = new StringBuilder();

            while ((line = reader.readLine()) != null)
            {
                content.append(line).append(" ");
            }

            Analyzer analyzer = Analyzer.analyzeText(content.toString());
            System.out.println(analyzer);

        } catch (IOException e)
        {
            System.err.println("Hiba: " + e.getMessage());
            System.exit(0);
        }

        scanner.close();
    }
}